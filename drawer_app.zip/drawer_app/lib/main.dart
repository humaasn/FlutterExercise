import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
 
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Drawer'),
        centerTitle: true,
        actions: [

          // 쇼핑카트 아이콘 
          IconButton(
            onPressed: (){}, 
            icon: const Icon(Icons.shopping_cart),
            ),

          // 검색 아이콘
          IconButton(
            onPressed: (){}, 
            icon: const Icon(Icons.search),
            ),
        ],
      ),
      //Drawer 
      drawer: Drawer(
        //리스트뷰로 인하여 여러 개 넣을 수가 있다. 
        child: ListView(
          children: [
            // 가장 좌측에 보이는 피카츄
            UserAccountsDrawerHeader(
              currentAccountPicture: const CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-1.jpg'),
              ),
            
              otherAccountsPictures: const[
                CircleAvatar(
                  backgroundImage: AssetImage('images/pikachu-2.jpg'),
                ),
                CircleAvatar(
                  backgroundImage: AssetImage('images/pikachu-3.jpg'),
                ),
              ],
              accountName: const Text('Pikachu'), 
              accountEmail: const Text('pikachu@naver.com'),
              // 그림 클릭하면 함수 실행 
              onDetailsPressed: (){

                //-----
              },
              // header 부분 꾸미기 
              decoration: BoxDecoration(
                color: Colors.red[400],
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(40.0),
                  bottomRight: Radius.circular(40.0),
                ),
              ),

            ),
           
            // header 부분 제외한 부분 꾸미기 
            ListTile(
              leading:  const Icon(
                Icons.home,
                color: Colors.black,
              ),
              title: const Text('Home'),
              onTap:(){
                //---------
              },
            ),

            ListTile(
              leading:  const Icon(
                Icons.settings,
                color: Colors.black,
              ),
              title: const Text('설정'),
              onTap:(){
                //---------
              },
            ),

            ListTile(
              leading:  const Icon(
                Icons.question_answer,
                color: Colors.red,
              ),
              title: const Text('자주 묻는 질문'),
              onTap:(){
                //---------
              },
            ),
          ],
        ),
      ),
    );
  }
}
