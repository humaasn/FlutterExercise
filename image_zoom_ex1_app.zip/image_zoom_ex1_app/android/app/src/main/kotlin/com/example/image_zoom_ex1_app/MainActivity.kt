package com.example.image_zoom_ex1_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
