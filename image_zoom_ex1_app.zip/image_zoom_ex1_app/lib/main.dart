import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.green,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late String _lampImage;
  late double _lampWidth;
  late double _lampHeight;
  late String _buttonName;
  late String _lampSizeStatus;
  late bool _switch_1; 
  late bool _switch_2; 
  late bool _switch_3; 

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _lampImage = 'images/lamp_on.png'; 
    _lampWidth = 150; 
    _lampHeight = 300;
    _buttonName = '전구 확대';
    _lampSizeStatus = 'small';
    _switch_1= true;
    _switch_2= true;
    _switch_3= true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image 확대 및 축소'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // sizebox를 쓰는 이유는 전구 크기만 변동시키기 위해서 실행 
            SizedBox(
              child: Column(
                children: [
                  Image.asset(
                    _lampImage,
                    width: _lampWidth,
                    height: _lampHeight,
                  ),
                ],
              ),
              width: 350, 
              height: 650
            ),

            const SizedBox(
              height: 50,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
               Text(_buttonName ),
               const SizedBox(
                 width: 20,
               ),
               Text('전구스위치'),

               const SizedBox(
                 width: 20,
               ),

               Text('전구색깔'),
              
              ],
            ),



            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Switch(
                      value: _switch_2, 
                      onChanged: (value){
                        setState(() {
                          _switch_2=value;
                          _switchCheck1();
                        });
                      },
                    ),
                    const SizedBox(
                      width: 20,
                    ),

                     Switch(
                      value: _switch_1, 
                      onChanged: (value){
                        setState(() {
                          _switch_1=value;
                          _switchCheck();
                        });
                      },
                    ),

                    const SizedBox(
                      width: 20,
                    ),

                     Switch(
                      value: _switch_3, 
                      onChanged: (value){
                        setState(() {
                          _switch_3=value;
                          _switchCheck2();
                        });
                      },
                    ),
               
              ],
            )
          ],
        ),
      ),
    );
  }


 
  _switchCheck1(){
     setState(() {
      if(_switch_2 == true){
        _lampSizeStatus=='small';
        _lampWidth = 300; 
        _lampHeight = 600;
        _buttonName = '전구 확대';
        _lampSizeStatus = 'large';
      }else {
        _lampWidth = 150; 
        _lampHeight = 300;
        _buttonName = '전구 확대';
        _lampSizeStatus = 'small';
      }
    });

  }

  _switchCheck(){
    
    if(_switch_1==false) {
       _lampImage = 'images/lamp_off.png'; 
    }
    else{
      _lampImage = 'images/lamp_on.png';
    }

  }


   _switchCheck2(){
    
    if(_switch_3==false) {
       _lampImage = 'images/lamp_on.png'; 
    }
    else{
      _lampImage = 'images/lamp_red.png';
    }

  }
}

