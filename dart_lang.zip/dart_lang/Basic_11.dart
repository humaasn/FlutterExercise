class People{
    // field
    // late = 조금 있다가 변수 설정해줄게 
    String? name; 
    int? age; 
    String? gender;

    // constructor 
    People(String name, int age, String gender){
      this.name = name; 
      this.age = age; 
      this.gender = gender;
    }
    // method 
  }
  class Human{
    String? name; 
    int? age; 
    String? gender; 

    Human({String? name, int? age, String?gender}){
      this.name = name; 
      this.age = age; 
      this.gender;
    }
  }

  void main(){
    People people1 = People('James', 23, 'male'); 
    print(people1);

    Human human1 = Human(
      name:'James' );
    Human human2 = Human(
      name: 'Cathy', gender: 'female' );
  }