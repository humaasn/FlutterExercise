// 비동기 처리 

void main(){

  checkVersion(); 
  print('end Process');
 
}
  // 비동기식 처리 시간 출력 
 Future checkVersion() async{
    var version = await lookUpVersion();
    print(version);
  }  

  // 시간 처리 
  int lookUpVersion(){
    return 12; 
  }