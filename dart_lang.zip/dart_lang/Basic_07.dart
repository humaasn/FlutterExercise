void main(){
  String name1 = '유비'; 
  name1 = '조조';

  // 변수 수정 불가 
  final String name2 = '관우'; 
  
  // flutter const를 많이 쓴다. 
  const String name3 = '조자룡';
}