void main(){
  List<int> numList = [1,3,5,7,9];

  // for문 이용하여 합계 구하기 
  /*
  int result = 0 ;
  for(int i=0;i<numList.length;i++){
    result += numList[i];
  }
  */
  //print(result);

  List<int> numList1 = [2,4,6,8,10];

  int sum(List flist){
    int aSum = 0; 
    for(int i in flist){
      aSum += i; 
    }
    return aSum;
  }
  /* void 진행 
  sum2(List flist){
    int aSum = 0; 
    for(int i in flist){
      aSum += i; 
    }
    print(aSum);
  }
  */

  int result = sum(numList); 
  print(result);

  int result1 = sum(numList1);
  print(result1);
 



}//main
