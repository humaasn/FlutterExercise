void main(){
  // list Collection
  List threeKingdoms = []; 

  // List에 데이터 추가하기 
  threeKingdoms.add('위');
  threeKingdoms.add('촉');
  threeKingdoms.add('오');

  print(threeKingdoms);
  // 원하는 데이터만 불러오기 
  print(threeKingdoms[0]);

  // list 수정 
  threeKingdoms[0] = "We"; 
  print(threeKingdoms); 

  // list 삭제 
  threeKingdoms.removeAt(1); 
  print(threeKingdoms); 

  threeKingdoms.remove('We');
  print(threeKingdoms); 

  // list의 갯수파악 
  print(threeKingdoms.length); 

  threeKingdoms.add(1); 
  print(threeKingdoms);   

  // list의 정해진 변수 타입의 데이터만 추가하기 
  List<String> threeKingdoms2 = []; // java bean/dto 

  threeKingdoms2.add('we'); 
  //threeKingdoms2.add(1); 

  List<String> threeKingdoms3 = ['위', '촉', '오']; 
  


}