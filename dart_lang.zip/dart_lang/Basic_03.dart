void main(){
  int intNum1 = 30; 
  int intNUm2 = 20; 
  // 사착연산 
  print(intNum1 + intNUm2);
  print(intNum1 - intNUm2);
  print(intNum1 * intNUm2);
  print(intNum1 / intNUm2);
  print(intNum1 % intNUm2);
  print(intNum1 ~/ intNUm2); // s

}