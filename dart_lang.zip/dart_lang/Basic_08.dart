void main(){
  // optional: null Safety 
  int num1 = 10; 
  
  // null 값 허용 
  int? num2 = null;
  num2 = 8;
  print(num2);
}