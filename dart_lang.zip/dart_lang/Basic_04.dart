void main(){
  String str1 = '유비';
  String str2 = '장비';

  print(str1+':'+str2);

  // 문자열 보간법 
  print('$str1 : $str2');

  // 정수의 문자열 보간법 
  int intNum1 = 170; 
  int intNum2 = 70;

print('intNum1과 intNum2의 합은 $intNum1 + $intNum2 입니다.') ;
print('intNum1과 intNum2의 합은 ${intNum1 + intNum2} 입니다.') ;

var result = 'intNum1과 intNum2의 합은 ${intNum1 + intNum2} 입니다.'; 
print(result);
}