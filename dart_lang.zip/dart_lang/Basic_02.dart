void main(){
  // 변수선언
  // var 변수 선언 : 데이터에 의한 추론형 변수 선언 
  // String도 가능 
  var name = '유비';
  print(name);
}