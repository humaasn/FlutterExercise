void main(){
  //Map: Key와 Value로 이루어진 Collection 

  Map fruits = {
    'Apple' : '사과', 
    'Grape' : '포도',
    'watermelon' : '수박'
  }; 

  print(fruits); 
  print(fruits['Apple']);

  // 수정 
  fruits['watermelon'] = '시원한 수박'; 

  // 추가
  fruits['banana'] = '바나나'; 
  print(fruits);

  // Generic을 선언하여 map 구성하기 

  Map<String, int> fruitsPrice = {
    'Apple' : 1000, 
    'Grape' : 2000,
    'watermelon' : 3000
  }; 

  print(fruitsPrice['Apple']);

}