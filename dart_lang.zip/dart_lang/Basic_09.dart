void main(){
  int score = 85; 

  // if문  학점 변경하기 

  if(score>=90){
    print('A');
  }
  else if(score>=80){
    print('B');
  }
  else{
    print('C');
  }



switch(score ~/ 10) {
  case 9 :
    print('A');
    break;
  case 8:
    print('B');
    break;
  default:
    print('C');
    break;
  }

  // 삼항 연산자 
bool isPublic = true; 

var visibility = isPublic ? 'public' : 'private'; 

print(visibility);
}

