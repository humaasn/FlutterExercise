void main(){
  // 화면 출력 
  print('hello world');
  
}