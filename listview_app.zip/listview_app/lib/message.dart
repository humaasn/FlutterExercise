class Message{
  // 인스턴스를 만들지않고 직접 가져다 쓴다
  static String workList = ''; 
  static String imagePath = '';
  // 구분자가 필요하다. 
  // 구분자가 없으면 계속해서 반복이 된다.
  static bool action = true;
}