// Dto 
import 'package:flutter/material.dart';

class TodoList{
  //field
  String imagePath;
  String workList;

  //Constructor
  TodoList({
    required this.imagePath, required this.workList
  });

}