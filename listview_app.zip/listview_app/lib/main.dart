import 'package:flutter/material.dart';
import 'package:listview_app/detail_list.dart';
import 'package:listview_app/insert_list.dart';
import 'package:listview_app/table_list.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    // materialApp은  어디로 가야 할지 경로를 지정 
    return MaterialApp(
      initialRoute: '/',
      routes: {
        '/' : (context){
          return const TableList();
        },
        '/insert' : (context){
          return const InsertList();
        },
        '/detail' : (context){
          return const DetailList();
        },
      }
    );
  }
}

