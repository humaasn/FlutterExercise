import 'package:flutter/material.dart';
import 'package:listview_app/message.dart';

class InsertList extends StatefulWidget {
  const InsertList({ Key? key }) : super(key: key);

  @override
  _InsertListState createState() => _InsertListState();
}

class _InsertListState extends State<InsertList> {

  TextEditingController textController = TextEditingController();
  late bool switch1;
  late bool switch2;
  late bool switch3;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    switch1 = false;
    switch2 = false;
    switch3 = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text('add View'),
      ),

      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Center(
          child: Column(
            children: [
            // 구매  
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('구매'),

              Switch(
                value: switch1, 
                onChanged: (value){
                  setState(() {
                    switch1=value; 
                    if(switch1==false){
                      Message.imagePath = '';
                    }else{
                      Message.imagePath = "images/cart.png";
                    }   
                  });
                }
              ),

              Image.asset("images/cart.png"),

              ],
            ),


            // 약속
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('약속'),

              Switch(
                value: switch2, 
                onChanged: (value){
                  setState(() {
                    switch2=value; 
                    if(switch2==false){
                      Message.imagePath = '';
                    }else{
                      Message.imagePath = "images/clock.png";
                    }   
                  });
                }
              ),

              Image.asset("images/clock.png"),

              ],
            ),

            // 스터디
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('스터디'),

              Switch(
                value: switch3, 
                onChanged: (value){
                  setState(() {
                    switch3=value; 
                    if(switch3==false){
                      Message.imagePath = '';
                    }else{
                      Message.imagePath = "images/pencil.png";
                    }   
                  });
                }
              ),

              Image.asset("images/pencil.png"),

              ],
            ),


   

              TextField(
                controller: textController,
                decoration: const InputDecoration(
                  labelText: '목록을 입력하세요.',
                ),
                keyboardType: TextInputType.text,
              ),

              const SizedBox(
                height: 50,
              ),

              ElevatedButton(
                onPressed: (){
                  if(textController.text.isNotEmpty){
                    addList();
                  }
                  Navigator.pop(context);
                }, 
                child: const Text('OK'),
              ),
            ],
          ),
        ),
      ),
      
    );
  }


  void addList(){
    Message.imagePath ;
    Message.workList = textController.text;
    Message.action = true;
  }





}