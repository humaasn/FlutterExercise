import 'package:charts_flutter/flutter.dart' as charts;

class DeveloperSeries {
  late String gu;
  late double coffee;
  late charts.Color barColor;

  DeveloperSeries({
    required this.gu,
    required this.coffee,
    required this.barColor,
  });
}