import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert'; //

class ThirdPage extends StatefulWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  _ThirdPageState createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  TextEditingController restaurantController = TextEditingController();
  TextEditingController bakeryController = TextEditingController();
  TextEditingController childrenController = TextEditingController();
  TextEditingController adolescenceController = TextEditingController();
  TextEditingController adultController = TextEditingController();
  TextEditingController oldageController = TextEditingController();

  late String restaurant;
  late String bakery;
  late String children;
  late String adolescence;
  late String adult;
  late String oldage;

  String result = 'all';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('machine'),
        backgroundColor: Colors.black87
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              children: [
                TextField(
                  controller: restaurantController,
                  decoration: const InputDecoration(
                      labelText: '음식점 점포 수는 2019년 기준 18,906개입니다.'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: bakeryController,
                  decoration: const InputDecoration(
                      labelText: '제과점 점포 수는 2019년 기준 2,295개입니다.'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: childrenController,
                  decoration: const InputDecoration(
                      labelText: '유아동기의 인구수는 2019년 기준: 357,781,318명입니다.'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: adolescenceController,
                  decoration: const InputDecoration(
                      labelText: '청소년기의 인구수는 2019년 기준 1,068,223,170명입니다.'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: adultController,
                  decoration: const InputDecoration(
                      labelText: '성인기의 인구수는 2019년 기준 4,181,409,363명입니다.'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: oldageController,
                  decoration: const InputDecoration(
                      labelText: '노년기의 인구수를 입력하세요. ex) 2019년 기준: 1,239,878,170명'),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 20,),
                ElevatedButton(
                  onPressed: () {
                    restaurant = restaurantController.text.toString();
                    bakery = bakeryController.text.toString();
                    children = childrenController.text.toString();
                    adolescence = adolescenceController.text.toString();
                    adult = adultController.text.toString();
                    oldage = oldageController.text.toString();
                    getJSONData();
                  },
                  child: const Text('분석시작'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  getJSONData() async {
    //-
    var url = Uri.parse(
        'http://localhost:8080/Flutter/request_cafe.jsp?restaurant=$restaurant&bakery=$bakery&children=$children&adolescence=$adolescence&adult=$adult&oldage=$oldage');
    var response = await http.get(url);
    setState(() {
      var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
      result = dataConvertedJSON['result'];
    });
    _shwoDialog(context);
  }

  _shwoDialog(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('점포 수 예측 결과'),
            content: Text('분석 결과 점포수는 $result입니다.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('확인'),
              ),
            ],
          );
        });
  }
} // << End