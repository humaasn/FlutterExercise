


import 'package:coffee_app/bar/bar_view.dart';
import 'package:coffee_app/line/line_view.dart';
import 'package:coffee_app/list/list.dart';
import 'package:coffee_app/machine/machine.dart';
import 'package:coffee_app/pie/pie_view.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>
    with SingleTickerProviderStateMixin {
  late TabController controller;

  @override
  void initState() {
    super.initState();
    controller = TabController(length: 5, vsync: this);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: const Text('IRIS Data'),
      // ),
      body: TabBarView(
        children: const [SecondPAge(),ThirdPage(),BarChartView(),PieChartView(),LineChartView()],
        controller: controller,
      ),
      bottomNavigationBar: Container(
        color: Colors.amber[50],
        height: 80,
        child: TabBar(
          labelColor: Colors.blueAccent,
          controller: controller,
          tabs: const [
            Tab(
              icon: Icon(Icons.list,size: 20,color: Colors.grey,),
              child: Text('LIST', style: TextStyle(fontSize: 10, color: Colors.black))
            ),
            
            Tab(
              icon: Icon(Icons.android,size: 20,color: Colors.grey),
              child: Text('MACHINE', style: TextStyle(fontSize: 10, color: Colors.black))
              
            ),
            Tab(
              icon: Icon(Icons.bar_chart,size: 20,color: Colors.grey),
              child: Text('CAFE', style: TextStyle(fontSize: 10, color: Colors.black))
            ),
            Tab(
              icon: Icon(Icons.pie_chart,size: 20,color: Colors.grey),
              child: Text('카페당 인구', style: TextStyle(fontSize: 10, color: Colors.black))
            ),
            Tab(
              icon: Icon(Icons.people_alt,size: 20,color: Colors.grey),
              child: Text('생활인구', style: TextStyle(fontSize: 10, color: Colors.black))
            ),
          ],
        ),
      ),
    );
  }
}

