class PieMSG {
  late String gu;
  late double guSum;

  PieMSG({
    required this.gu,
    required this.guSum
  });
}