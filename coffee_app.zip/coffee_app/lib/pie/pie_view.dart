
import 'package:coffee_app/pie/pie_chart.dart';
import 'package:coffee_app/pie/pie_msg.dart';
import 'package:flutter/material.dart';
import 'dart:convert'; // for json
import 'package:http/http.dart' as http;

class PieChartView extends StatefulWidget {
  const PieChartView({ Key? key }) : super(key: key);

  @override
  _PieChartViewState createState() => _PieChartViewState();
}

class _PieChartViewState extends State<PieChartView> {
  late List<PieMSG> data;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    data = [];
    getJSONData1();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('카페 하나당 생활인구'),
        backgroundColor: Colors.black87
      ),
      body: Center(
        child: DeveloperPieChart(data: data),
      ),
    );
  }
  ///////////////////////////////////////
//   Future<String> getJSONData1() async {
//     var url = Uri.parse('http://192.168.43.109:8080/Flutter/coffee_pie_flutter.jsp');
//     var response = await http.get(url);
//     var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
//     List result = dataConvertedJSON['results'];

//     setState(() {
//       for (int i = 0; i < 5; i++) {
//         data.add(PieMSG(
//             gu: result[i]['gu'],
//             guSum: double.parse(result[i]['guSum'])
//             ));
//       }
//       // data.addAll(result);
//     });
//     return response.body;
//   }
// }


 Future<String> getJSONData1() async {
    var url = Uri.parse('http://localhost:8080/Flutter/coffee_pie_flutter.jsp');
    var response = await http.get(url);
    var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
    List result = dataConvertedJSON['results'];

    setState(() {
      for (int i = 0; i < 5; i++) {
        data.add(PieMSG(
          gu: result[i]['gu'],
          guSum: double.parse(result[i]['guSum'])
        ));
      }
      // data.addAll(result);
    });
    return response.body;
  }
}