
import 'package:coffee_app/pie/pie_msg.dart';
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;

class DeveloperPieChart extends StatelessWidget {
  final List<PieMSG> data;

  const DeveloperPieChart({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    List<charts.Series<PieMSG, String>> series = [
      charts.Series(
          id: "cafe",
          data: data,
          labelAccessorFn: (PieMSG series, _) =>
              series.gu.toString(),
          domainFn: (PieMSG series, _) => series.gu.toString(),
          measureFn: (PieMSG series, _) => series.guSum,
          )
    ];
    return SizedBox(
      height: 500,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              children: [
                const Text(
                  '생활인구 / 카페 의 상위 5개의 자치구',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: charts.PieChart<String>(
                    // ********
                    series,
                    animationDuration: const Duration(seconds: 3),
                    defaultRenderer: charts.ArcRendererConfig(
                        customRendererId: 'novoId',
                        arcRendererDecorators: [
                          charts.ArcLabelDecorator(
                              labelPosition: charts.ArcLabelPosition.inside)
                        ]),
                    animate: true,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
