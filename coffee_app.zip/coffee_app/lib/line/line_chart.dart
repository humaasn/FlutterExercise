import 'package:coffee_app/line/line_msg.dart';
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts; // ************

class DeveloperLineChart extends StatelessWidget {
  final List<LineMSG> data;
  final List<LineMSG> data2; // <<<<<<<<<<<<<<
  const DeveloperLineChart(
      {Key? key, required this.data, required this.data2}) // <<<<<<<<<<<<<<
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // data
    List<charts.Series<LineMSG, num>> series = [
      // data
      charts.Series(
          id: "developers",
          data: data,
          domainFn: (LineMSG series, _) => series.year,
          measureFn: (LineMSG series, _) => series.PeopleSum,
          colorFn: (LineMSG series, _) => series.barColor),

      // data2 // <<<<<<<<<<<<<<
      charts.Series(
          id: "developers2",
          data: data2,
          domainFn: (LineMSG series, _) => series.year,
          measureFn: (LineMSG series, _) => series.PeopleSum,
          colorFn: (LineMSG series, _) => series.barColor)
    ];

    return SizedBox(
      height: 500,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              children: [
                const Text(
                  '강남구와 금천구의 생활인구 추이 비교',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Expanded(
                  child: charts.LineChart(
                    series,
                    animationDuration: const Duration(seconds: 3),
                    domainAxis: const charts.NumericAxisSpec(
                      tickProviderSpec:
                          charts.BasicNumericTickProviderSpec(zeroBound: false),
                      viewport: charts.NumericExtents(2016.9, 2019.1),
                    ),
                    animate: true,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
