import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  late String _buttonState ;
  // 중요하다 initState 초기값 설정 
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print('inistate(): 기본값을 설정합니다.');
    _buttonState = 'OFF';
  }

  @override
  void didChangeDependencies() {
    // TODO: implement didChangeDependencies
    super.didChangeDependencies();
    print('didChangeDependencies() 호출됨');
  }

  @override
  void didUpdateWidget(covariant MyHomePage oldWidget) {
    // TODO: implement didUpdateWidget
    super.didUpdateWidget(oldWidget);
    print('didUpdateWidget() 호출됨');
  }

  @override
  void deactivate() {
    // TODO: implement deactivate
    super.deactivate();
    print('deactivate() 호출됨');
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    print('dispose() 호출됨');
  }

  @override
  Widget build(BuildContext context) {
    print('build()가 호출됨.');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter Life Cycle'),
        ),
    body: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: (){
              _onClick();
            }, 
            child: const Text('버튼을 누르세요')
            ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('버튼 상태 : '),
              const SizedBox(
                width: 10,
              ),
              Text(_buttonState),
            ],
          ),
        ],
      ),
    ),
    );
  }
  _onClick(){

    print('_buttonState : $_buttonState');
    
    // _buttonState가 변하는 걸 알기 위해서는 setSate를 무조건 써줘야 된다. 
    setState(() {
      if(_buttonState == 'OFF'){
         _buttonState = 'ON';
      }
      else{
        _buttonState = 'OFF';
      }
    });

  }

}
