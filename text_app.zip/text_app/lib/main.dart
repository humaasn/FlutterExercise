import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(  
        primarySwatch: Colors.red, // title 배경색상 변경
      ),
      home: const MyHomePage(),
    );
  }
}

class  MyHomePage extends StatelessWidget { // stl tab 누르기 
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Text App') // myhomepage title명 지정 
      ),
      body: Center ( // 파란줄이 뜬다면 상위 폴더에 add const 클릭 (const는 안바꾸겠다는 뜻)
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // 컬럼을 가운데로 정렬 (컬럼의 속성지정)
          children: const [
            Text('유비'),
            SizedBox( // 컬럼 사이 간격 띄우기 
              height: 50.0,
            ),
            Text('관우'), 
            Text('장비')
          ],
        ),
      ),
    );
  }
}



