import 'package:flutter/material.dart';

import 'screen.dart';
import 'screen1st.dart';
import 'screen2nd.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({ Key? key }) : super(key: key);
// 화면 이동 하기 위한 controller 
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/', // 첫번째 시작점 /
      routes: {
        '/' : (context){
          return const Screen();
        }, 
        '/1st' : (context){
          return const Screen1st();
        },
        '/2nd' : (context){
          return const Screen2nd();
        }
      },
    );
  }
}
