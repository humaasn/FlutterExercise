package com.example.navigator_class_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
