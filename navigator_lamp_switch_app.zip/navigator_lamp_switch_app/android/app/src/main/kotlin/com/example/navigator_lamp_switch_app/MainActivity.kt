package com.example.navigator_lamp_switch_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
