class Message{
  static String code ='';
  static String name ='';
  static String dept ='';
  static String phone ='';
}