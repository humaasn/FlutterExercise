import 'package:flutter/material.dart';
import 'package:navigator_lamp_switch_app/message.dart';
import 'package:navigator_lamp_switch_app/second_page.dart';

class Modify extends StatefulWidget {
  const Modify({ Key? key }) : super(key: key);

  @override
  _ModifyState createState() => _ModifyState();
}

class _ModifyState extends State<Modify> {
  late bool switch1; 
  late bool switch2; 
  late String color; 
  late String status;



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    switch1 = false;
    switch2 = false;
    color = "Red";
    status = 'Off';

  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('수정화면'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children:[
                Text(color),
                Switch(
                  value: switch1, 
                  onChanged: (value){
                    setState(() {
                      switch1 = value;
                      if(switch1 == false){
                          Message.imagePath = 'images/lamp_on.png';
                          color = 'yellow';
                        }else{
                          Message.imagePath = 'images/lamp_red.png';
                          color = 'Red';
                        }
                    });
                  }
                ),
              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children:[
                Text(status),
                Switch(
                  value: switch2, 
                  onChanged: (value){
                    setState(() {
                      switch2 = value;
                      if(switch2 == false){
                        Message.imagePath = 'images/lamp_off.png';
                        status = 'Off';
                        
                      }else{
                        Message.imagePath = 'images/lamp_on.png';
                        status = 'On';
                      }
                    });
                  }
                ),
              ],
            ),

            ElevatedButton(
              onPressed: (){
                  //addList();
                  Navigator.push(context, MaterialPageRoute(builder: (context){
                  return const SecondPage();
                  }));
              }, 
              child: const Text('OK'),
            ),

          ],
        ),
      ),
    );
  }

/*
  _onColor(){
    setState(() {
      if(switch1 == false){
      Message.imagePath = 'images/lamp_on.png';
      color = 'yellow';
    }else{
      Message.imagePath = 'images/lamp_red.png';
      color = 'Red';
    }
    });
   
  }
  */
  /*
  _onStatus(){
      setState(() {
        if(switch2 == false){
      Message.imagePath = 'images/lamp_off.png';
      status = 'Off';
    }else{
      Message.imagePath = 'images/lamp_on.png';
      status = 'On';
    }
      });
     
  }
  */
/*
    void addList(){
      Message.imagePath ;
  }
  */
}




