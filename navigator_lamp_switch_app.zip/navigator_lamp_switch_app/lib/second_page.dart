import 'package:flutter/material.dart';
import 'package:navigator_lamp_switch_app/message.dart';

class SecondPage extends StatefulWidget {
  const SecondPage({ Key? key }) : super(key: key);

  @override
  _SecondPageState createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {

  late String imagePath ;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    imagePath = 'images/lamp_off.png';
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Main 화면'),
        actions: [
          IconButton(
            onPressed: (){
              //Message.imagePath= imagePath;
              Navigator.pushNamed(context, '/modify').then((value) => rebuildData()); 
            },
            icon: const Icon(Icons.pending_actions),
          ),
        ],
      ),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(imagePath,
            height: 200,
            width: 200,
            ),
          ],
        ),

      ),
      
    );
  }



  rebuildData(){
    //if(Message.action == true){
       setState(() {
        print(imagePath);
       imagePath = Message.imagePath;
        // 1번만 사용되게 action을 false로 바꾼다. 
        //Message.action = false;
    //
    });
  }



}