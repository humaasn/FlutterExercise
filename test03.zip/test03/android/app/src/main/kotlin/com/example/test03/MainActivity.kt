package com.example.test03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
