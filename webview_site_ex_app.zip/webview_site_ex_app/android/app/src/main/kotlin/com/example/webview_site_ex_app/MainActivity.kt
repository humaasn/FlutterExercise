package com.example.webview_site_ex_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
