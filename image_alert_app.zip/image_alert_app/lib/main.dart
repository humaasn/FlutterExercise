import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.red,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}




class _MyHomePageState extends State<MyHomePage> {
  late String imag;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    imag = 'images/lamp_on.png';
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Alert를 이용한 메시지 출력'),
      ),


      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              imag,
              height: 350,
              width: 400,
            ),
            const SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                 ElevatedButton(
                  onPressed: (){
                    setState(() {
                      if(imag=='images/lamp_on.png'){
                        _showDialog_open(context);
                      }
                      if(imag=='images/lamp_off.png'){
                        _showDialog_close(context);
                      }
                    });
    
                }, 
                  child: const Text('켜기'),
                ),

                const SizedBox(
                  width: 20,
                ),




                ElevatedButton(
                  onPressed: (){
                  setState(() {
                    if(imag=='images/lamp_off.png'){
                        _showDialog_open1(context);
                      }

                      if(imag=='images/lamp_on.png'){
                        
                        _showDialog_close1(context);
                      }
                  });
                }, 
                  child: const Text('끄기'),
                ),
              ],

            ),
          ],
        ),
      ),
    );
  }



  _showDialog_open(BuildContext context)
    {
      showDialog(
        context: context, 
        builder: (BuildContext context){
        // alterdialog() == 팝업 
        return AlertDialog(
          title: const Text('경고'),
          content: const Text('현재 램프는 켜진 상태입니다.'),
          actions:[
            
            TextButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동
                // Navigator.push(context, MaterialPageRoute(builder: (context){
                // return const SecondPage();
                // }));
                },
              child: const Text('네 알겠습니다.')
            ),
          ],
        );
        }
      );
    } 


    _showDialog_close(BuildContext context)
    {
      showDialog(
        context: context, 
        builder: (BuildContext context){
        // alterdialog() == 팝업 
        return AlertDialog(
          title: const Text('램프 켜기'),
          content: const Text('램프를 켜시겠습니까?'),
          actions:[

            TextButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동
                setState(() {
                  imag = 'images/lamp_on.png';
                });
                //imag = 'images/lamp_off.png';
                // Navigator.push(context, MaterialPageRoute(builder: (context){
                // return const SecondPage();
                // }));
                },
              child: const Text('네')
            ),

             TextButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동
                //imag = 'images/lamp_off.png';
                // Navigator.push(context, MaterialPageRoute(builder: (context){
                // return const SecondPage();
                // }));
                },
              child: const Text('아니요')
            ),


          ],
        );
        }
      );
    } 


    _showDialog_open1(BuildContext context)
    {
      showDialog(
        context: context, 
        builder: (BuildContext context){
        // alterdialog() == 팝업 
        return AlertDialog(
          title: const Text('경고'),
          content: const Text('현재 램프는 꺼진 상태입니다.'),
          actions:[
            TextButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동
                // Navigator.push(context, MaterialPageRoute(builder: (context){
                // return const SecondPage();
                // }));
                },
              child: const Text('네 알겠습니다.')
            ),
          ],
        );
        }
      );
    } 


    _showDialog_close1(BuildContext context)
    {
      showDialog(
        context: context, 
        builder: (BuildContext context){
        // alterdialog() == 팝업 
        return AlertDialog(
          title: const Text('램프 끄기'),
          content: const Text('램프를 끄시겠습니까?'),
          actions:[

            TextButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동
                setState(() {
                   imag = 'images/lamp_off.png';
                });
                //imag = 'images/lamp_on.png';
                // Navigator.push(context, MaterialPageRoute(builder: (context){
                // return const SecondPage();
                // }));
                },
              child: const Text('네')
            ),

             TextButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동
                //imag = 'images/lamp_off.png';
                // Navigator.push(context, MaterialPageRoute(builder: (context){
                // return const SecondPage();
                // }));
                },
              child: const Text('아니요')
            ),


          ],
        );
        }
      );
    } 






}