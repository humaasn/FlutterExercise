import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}


class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  late Color _color;
  late var switchValue;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _color=Colors.blue;
    switchValue = false;
  }
  /*
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Change button Color & text'),
      ),

      body: Center(
        child: ElevatedButton(
          onPressed: (){
            _onClick();
          }, 
          style: ButtonStyle(
          backgroundColor:  MaterialStateProperty.all(_color),
          ),
          child: Text(_buttonText)
          ),
        ),
    );
  }
  */
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Switch'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          ElevatedButton(
            onPressed: (){
              //----
            }, 

            style: ButtonStyle(backgroundColor: MaterialStateProperty.all(_color)),

            child: const Text('flutter'),
            ),
            const SizedBox(
              height: 30.0,
            ),
          Switch(
            value: switchValue, 
            onChanged: (value){
              setState(() {
                switchValue=value;
                print('$switchValue');
                if(switchValue==false){
                  _color=Colors.blue;
                }else{
                  _color=Colors.red;
                }

              });
            //switchValue=value;
          } // action 부분 
        ),

          ],
        ), 
      ),
    );
  }

}
