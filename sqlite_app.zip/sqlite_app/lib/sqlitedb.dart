import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqlite_app/user.dart';
// SQLite 데이터 유형 
// Text = Null, Text, BLOB를 사용하여 모든 데이터 저장 
// 

class Sqlite{

  // SQLite 연동
  Future<Database> initializeDB() async {
    String path = await getDatabasesPath();
    print(path);
    return openDatabase(
      join(path, 'test.db'), // Database 생성 
   
  // create table 구문 실행 
    onCreate: (db, version) { 
      return db.execute( 
        "create table users(name text, content text)", 
        ); 
      },
      version: 1,
    );
  }
  // insert 
  Future<int> insertUser(User users) async {
    int result = 0;
    Database db = await initializeDB();
    result = await db.rawInsert(
          'insert into users (name, content) values (?,?)',
          [users.name, users.content]);
    print(result);
    return result;
  }

    //Read
  getname(String name) async {
    var res;
    Database db = await initializeDB();
   res = await db.rawQuery('SELECT name, content FROM users WHERE name = ?', [name]);

    print(res);
    return res;
    //return res.isNotEmpty ? User(name: res.first['name'], content: res.first['content']) : Null;
  }





  //   //Read All
  // Future<List<User>> getAllUsers() async {
  //   Database db = await initializeDB();
  //   var res = await db.rawQuery('SELECT * FROM user');
  //   List<Dog> list = res.isNotEmpty ? res.map((c) => Dog(id:c['id'], name:c['name'])).toList() : [];

  //   return list;
  // }

  // // Read
  //  Future<List<User>> retrieveUsers() async {
  //   print("read");
  //   final Database db = await initializeDB();
  //   final List<Map<String, Object?>> queryResult =
  //       await db.rawQuery('select * from users where name = "조조"');
  //   return queryResult.map((e) => User.fromMap(e)).toList();
  // }


  // // update 
  // Future<int> updateUser(String name, String content) async {
  //   print("update");
  //   print(name);
  //   print(content);
  //   int result = 0;
  //   final Database db = await initializeDB();
  //   //for (var user in users) {
  //     result = await db.rawUpdate(
  //       'UPDATE users SET name = ?, content = ? WHERE name = ?',
  //       [name,content,name]);
  //   //}
  //   return result;
  // }

  // Future<List<User>> retrieveUsers() async {
  //   print("read");
  //   final Database db = await initializeDB();
  //   final List<Map<String, Object?>> queryResult =
  //       await db.rawQuery('select * from users');
  //   return queryResult.map((e) => User.fromMap(e)).toList();
  // }

  // Future<void> deleteUser(String name) async {
  //   print("Delete");
  //   final db = await initializeDB();
  //   await db.rawDelete('delete from users where name = ?', [name]);
  // }

  

}

