import 'package:flutter/material.dart';

class User{

  late String name;
  late String content;
  
  User(
    {
      required this.name,
      required this.content
    });

  User.fromMap(Map<String, dynamic> res)
    :
        name = res["name"],
        content = res["content"];

  Map<String, Object?> toMap() {
    return {
      'name': name,
      'content': content

    };
  }

}