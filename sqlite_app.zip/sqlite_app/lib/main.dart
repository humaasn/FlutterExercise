import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqlite_app/sqlitedb.dart';
import 'package:sqlite_app/user.dart';

void main() {
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  TextEditingController namecontroller = TextEditingController();
  TextEditingController contentcontroller = TextEditingController();

  String name = "";
  String content = "";
  late var test ;
  //List result = [];


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    namecontroller.text = "";
    contentcontroller.text = "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SQLite CRUD')
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Container(
              width: 200,
              child: TextField(
                controller: namecontroller,
                decoration:  const InputDecoration(
                  label: Text("이름"),
                ),
                keyboardType: TextInputType.text,
              ),
            ),

            Container(
              width: 200,
              child: TextField(
                controller: contentcontroller,
                decoration: const InputDecoration(
                  label: Text("내용"),
                ),
              ),
            ),

            // ElevatedButton(
            //   onPressed: (){
            //     Sqlite db = Sqlite();
            //     db.initializeDB();
            //   }, 
            //   child: const Text("CREATE")
            // ),

            // ElevatedButton(
            //   onPressed: (){
            //     name = namecontroller.text.toString();
            //     content = contentcontroller.text.toString();
            //     Sqlite db = Sqlite();
            //     db.updateUser(name, content );
            //   }, 
            //   child: const Text("UpDate")
            // ),


            ElevatedButton(
              onPressed: (){
                name = namecontroller.text.toString();
                Sqlite db = Sqlite();
                db.getname(name);
                var result = db.getname(name).toString;
                print(result);
                test = result;
                Navigator.push(context, MaterialPageRoute(builder: (context){
                return const MyHomePage();
          }));





               
              }, 
              child: const Text("READ")
            ),



            // ElevatedButton(
            //   onPressed: (){
            //     Sqlite db = Sqlite();
            //     db.deleteUser(name);
            //   }, 
            //   child: const Text("Delete")
            // ),

            ElevatedButton(
              onPressed: () async {
                Sqlite db = Sqlite();
                final e1 = User (name: namecontroller.text, content: contentcontroller.text); 
                await db.insertUser(e1); 
              }, 
              child: const Text("Insert")
            ),

            Text(test,
              style: const TextStyle(
                fontSize: 30,
              ),
            )
            




          ],
        ),
      ),
    );
  }
}



