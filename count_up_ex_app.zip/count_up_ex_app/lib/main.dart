import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
    late int count; 
    @override
  void initState() {
    // TODO: implement initState
    super.initState();
    count=0;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Count up'),
      ),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('현재 클릭수는 $count입니다.'),
            const SizedBox(
              height: 50.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [

                
                FloatingActionButton(
                  
                  child: const Icon(Icons.add),
                  onPressed: (){
                    setState(() {
                      count++;
                    });
                  },
                ),
                
                //style: ButtonStyle(),
                FloatingActionButton(
                  child: const Icon(Icons.exposure_minus_1),
                  onPressed: (){
                   setState(() {
                      count--;
                      
                    });
                  },
                ),
              ],

            )
          ],

        ),
      ),
      
    );
  }
}