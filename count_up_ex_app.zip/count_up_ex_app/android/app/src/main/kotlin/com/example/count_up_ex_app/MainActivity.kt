package com.example.count_up_ex_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
