import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const MyHomePage(),
    );
  }
}


class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title : const Text('Text Exercise 01'),
        backgroundColor: Colors.lightGreen,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Divider( // 나누기
              height: 30.0,
              color: Colors.grey,
              thickness: 0.5, // 선 굵기 
            ),
            Text('유비'),
            Text('관우'),
            Text('장비'),
            //SizedBox(
              //height: 30.0
            //),
            Divider( // 나누기
              height: 30.0,
              color: Colors.blue,
              thickness: 0.5, // 선 굵기 
            ),
            Text(
              '조조',
                style: TextStyle(// 글자 꾸미기 
                  color: Colors.blue,// 글자 색상 
                  fontSize: 28.0, // 글자 크기 
                  letterSpacing: 2.0, // 단어 공간 
                  fontWeight: FontWeight.bold, // 글자 타입 
              ),
            ),
            Text('여포'),
            Text('동탁'),
          ],
        )
      ),
    );
  }
}
