import 'dart:async';

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  List advertise = [
    '대',
    '한',
    '민',
    '국'
  ];

  late String kor ;
  late int count;

  int currentPage = 0;
  void initState() {
    // TODO: implement initState
    super.initState();
    kor = '';
    count = 0;
    Timer.periodic(const Duration(seconds: 3), (Timer timer) { 
      _fontchar();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LED 광고'),
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        backgroundColor: Colors.grey,
      ),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
             Text(

                kor,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 50,
                ),
            ),

          ],
        )
          
        ),
    );
  }
  _fontchar(){
    setState(() {
      kor ='';
      count++;
      if (count== advertise.length+1){
        count = 0;
      }
      if(count == currentPage){
        count = 0; 
        //kor ='';
      }
      for(currentPage = 0; currentPage < count; currentPage++){
        kor += advertise[currentPage];
      }

      

    });
  }
    
}

