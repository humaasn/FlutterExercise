import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class  MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image fitting')
      ),
      body: Center(
        child: Column(
          children:  [

            Image.asset(
              'images/turtle.gif',
              width: 50,
              height: 100,
              fit: BoxFit.fill, // width, height 크기에 맞게 꽉 채움
            ),

             Image.asset(
              'images/turtle.gif',
              width: 50,
              height: 100,
              fit: BoxFit.contain, // width, height 비율에 맞게 가장 크게 넣어줌 
            ),

             Image.asset(
              'images/turtle.gif',
              width: 50,
              height: 100,
              fit: BoxFit.cover, // 이미지가 잘림 
            ),

             Image.asset(
              'images/turtle.gif',
              width: 50,
              height: 100,
              fit: BoxFit.scaleDown, // (contain과 비슷)이미지와 파일사이즈가 줄어듬
            ),

          ],
        ),
      ),
    );
  }
}

