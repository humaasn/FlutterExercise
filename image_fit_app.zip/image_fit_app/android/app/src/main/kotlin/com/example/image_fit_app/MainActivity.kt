package com.example.image_fit_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
