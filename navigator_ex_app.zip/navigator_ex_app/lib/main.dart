import 'package:flutter/material.dart';
import 'package:navigator_ex_app/mail.dart';
import 'package:navigator_ex_app/receivedmail.dart';
import 'package:navigator_ex_app/sendmail.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/', // 첫번째 시작점 /
      routes: {
        '/' : (context){
          return const Mail();
        }, 
        '/Send' : (context){
          return const Send();
        },
        '/Received' : (context){
          return const Received();
        },
      },
    );
  }
}