import 'package:flutter/material.dart';

class Mail extends StatelessWidget {
  const Mail({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Navigator_AppBar'),
        actions: [
          IconButton(
            onPressed: (){
              Navigator.pushNamed(context, '/Send');
            }, 
            icon: const Icon(Icons.email),
            ),
          IconButton(
            onPressed: (){
              Navigator.pushNamed(context, '/Received');
            }, 
            icon: const Icon(Icons.email_outlined,),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              currentAccountPicture: const CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-1.jpg'),
              ),
            
              accountName: const Text('Pikachu'), 
              accountEmail: const Text('pikachu@naver.com'),
              // 그림 클릭하면 함수 실행 
              onDetailsPressed: (){

                //-----
              },
              // header 부분 꾸미기 
              decoration: BoxDecoration(
                color: Colors.red[400],
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(40.0),
                  bottomRight: Radius.circular(40.0),
                ),
              ),
            ),
            
            // 헤더 아래 부분 출력 
            ListTile(
              leading: const Icon(
                Icons.email,
              ),
              title: const Text('보낸 편지함'),
              onTap: (){
                Navigator.pushNamed(context, '/Send');
              },
            ),

            ListTile(
              leading: const Icon(
                Icons.email_outlined,
              ),
              title: const Text('받은 편지함'),
              onTap: (){
                Navigator.pushNamed(context, '/Received');
              },
            ),
          ],
        ),
      ),

      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.green),
              ),
              onPressed: (){
                Navigator.pushNamed(context, '/Send');
              }, 
              child: const Text('보낸편지함')
            ),

              ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.red),
              ),
              onPressed: (){
                Navigator.pushNamed(context, '/Received');
              }, 
              child: const Text('받은편지함')
            ),
          ],
        ),
      ),

    );
  }
}