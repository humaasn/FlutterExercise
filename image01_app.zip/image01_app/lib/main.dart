import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red[200],
      appBar: AppBar(
        title: const Text('image 01'),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const[
            //AssetImage('images/pikachu-1.jpg')
            Padding(
              padding: EdgeInsets.all(8.0),
              child: CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-1.jpg'),
                // Assetimage는 백그라운드 이미지에서만 사용가능 
                radius: 50, 
                // 반지름 크기 지정 
              ),
            ),

            Padding(// 핸드폰 픽셀 사이즈에 맞춰서 띄어줌 
              padding: EdgeInsets.all(8.0), // fromLTRB 각각 여백 지정 가능
              child: CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-2.jpg'),
                // Assetimage는 백그라운드 이미지에서만 사용가능 
                radius: 50, 
                // 반지름 크기 지정 
              ),
            ),


            Padding(
              padding: EdgeInsets.all(8.0),
              child: CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-3.jpg'),
                // Assetimage는 백그라운드 이미지에서만 사용가능 
                radius: 50, 
                // 반지름 크기 지정 
              ),
            ),
          ],
        ),
      ),
    );
  }
}

