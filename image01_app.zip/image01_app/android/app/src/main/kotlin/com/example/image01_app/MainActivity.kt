package com.example.image01_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
