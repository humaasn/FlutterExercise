package com.example.website_ex4_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
