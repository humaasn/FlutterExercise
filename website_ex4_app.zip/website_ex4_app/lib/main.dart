import 'dart:async';

import 'package:flutter/material.dart';
import 'package:webview_app/daum.dart';
import 'package:webview_app/google.dart';
import 'package:webview_app/naver.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
       
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin {

  final Completer<WebViewController> _controller = Completer<WebViewController>();
  
  bool isLoading = true;
  //------
  String siteName = 'www.google.com'; 
  late TabController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WebView-Tabbar'),
      ),
     


      // 화면 쌓아놓기 
      body: Stack(
        children: [
          WebView(
            initialUrl: 'https://www.google.com',
            javascriptMode: JavascriptMode.unrestricted,
            onWebViewCreated: (WebViewController webViewController){
              _controller.complete(webViewController);
            },
            onPageFinished: (finish){
              setState(() {
                isLoading = false;
              });
            },

            onPageStarted: (start){
              setState(() {
                isLoading = true;
              });
            },
          ),
          TabBarView(
            controller: controller,
            children: const[
              NaverPage(), GooglePage(), DaumPage()
            ],
          ),
        ],
      ),

      bottomNavigationBar: Container(
        color: Colors.yellowAccent,
        height: 100,
        child: TabBar(
          labelColor: Colors.blue,
          controller: controller,
          tabs:  const[
            
            Tab(
              icon: Icon(
                Icons.lock_clock_outlined,
                color: Colors.blue,
              ),
              text: '네이버',
            ),

            Tab(
              icon: Icon(
                Icons.verified_user_outlined,
                color: Colors.red,
              ),
              text: '구글',
            ),

             Tab(
              icon: Icon(
                Icons.verified_user_outlined,
                color: Colors.red,
              ),
              text: '다음',
            )
          ],
        ),
      ),
      
      
        // 화면 뒤로 가기 눌렀을 때, 
      floatingActionButton: FutureBuilder<WebViewController>(
        future: _controller.future,
        // snapshot 전 화면의 메모리가 저장 
        builder: (BuildContext context, AsyncSnapshot<WebViewController> controller){
          if(controller.hasData){

            return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children:  [
              FloatingActionButton(
                child: const Icon(Icons.arrow_back),
                backgroundColor: Colors.red,
                onPressed: (){
                controller.data!.goBack();
                }
               ),

               
              ],
            );

            /*
            return FloatingActionButton(
              child: 
                const Icon(Icons.arrow_back),
                backgroundColor: Colors.red,
                onPressed: (){
                controller.data!.goBack();
              },
              */

              
            //);
          }
          return Stack();
        }, 
        
      ),

      

      
      
    );
  }
  // controller를 통해 앱 사이를 연결 
  _reloadSite(){
    _controller.future.then((value) => value.loadUrl('https://$siteName'));
    // _controller.future.then((value){
    //   value.loadUrl('https://$siteName');
    // });
  }
}