import 'package:flutter/material.dart';

class SecondPage extends StatefulWidget {
  const SecondPage ({ Key? key }) : super(key: key);

  @override
  _SecondPageState createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orangeAccent,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(
              backgroundImage: AssetImage('images/pikachu-1.jpg'),
              radius: 50,
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const[
                CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-2.jpg'),
                radius: 50,
                ),
                SizedBox(
                  width: 20,
                ),
                CircleAvatar(
                backgroundImage: AssetImage('images/pikachu-3.jpg'),
                radius: 50,
                ),
                
              ],
            ),
          ],
        ),
      ),
      
    );
  }
}