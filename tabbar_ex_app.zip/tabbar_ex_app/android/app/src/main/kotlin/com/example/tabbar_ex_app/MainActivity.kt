package com.example.tabbar_ex_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
