import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
       
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController num1 = TextEditingController();
  TextEditingController num2 = TextEditingController();
  late int sum;
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    sum = 0;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('덧셈 구하기'),
      ),
      body: Center(
        child: Column(
          children: [

          // num1 입력 
            TextField(
              controller: num1,
              decoration: const InputDecoration(labelText: '첫번째 숫자를 입력하세요.'),
              keyboardType: TextInputType.number,
            ),

          // num2 입력 
            TextField(
              controller: num2,
              decoration: const InputDecoration(labelText: '두번째 숫자를 입력하세요.'),
              keyboardType: TextInputType.number,
            ),
          // 버튼 입력 
          ElevatedButton(
            onPressed: (){
              if(num1.text.isNotEmpty && num2.text.isNotEmpty){
                onClick();
              }
              if(num1.text.isEmpty || num2.text.isEmpty){
                  errorSnackBar(context);
              }
            }, 
            child: const Text('덧셈 계산')
            ),


            //     Text('입력하신 숫자의 합은 $sum 입니다',
            //     style: const TextStyle(
            //     color: Colors.red,
            //     fontSize: 24,),
            // ),
            

          ],
        ),
      ),
    );
  }

  onClick(BuildContext context){
    setState(() {
      sum = int.parse(num1.text) + int.parse(num2.text);
    });
    
    Text('입력하신 숫자의 합은 $sum 입니다',
      style: const TextStyle(
      backgroundColor: Colors.red,
      fontSize: 24,),
    );
  }

  

 errorSnackBar(BuildContext context){
    ScaffoldMessenger.of(context).showSnackBar(// snackbar message 출력
      const SnackBar(
      content: Text('숫자를 입력하세요'),
      duration: Duration(seconds: 2), // snackbar 출력시간
      backgroundColor: Colors.red,
      ),
    );
  }
}