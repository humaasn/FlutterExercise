package com.example.textfield_add_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
