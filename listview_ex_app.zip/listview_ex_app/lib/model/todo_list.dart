class TodoList{
  String imagePath;
  String nameList;
  String typeList;
  // String insectList;
  // String mamalList;

  //Constructor
  TodoList({
    required this.imagePath, required this.nameList, required this.typeList
  }); 

}