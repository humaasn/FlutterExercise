import 'package:flutter/material.dart';
import 'package:listview_ex_app/message.dart';
import 'package:listview_ex_app/model/todo_list.dart';

class TableList extends StatefulWidget {
  const TableList({ Key? key }) : super(key: key);

  @override
  _TableListState createState() => _TableListState();
}
// 곤충 영장류 포유류
class _TableListState extends State<TableList> {
  List<TodoList> todoList=[];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    todoList.add(TodoList(imagePath: 'images/bee.png', nameList: '벌', typeList: '곤충'));
    todoList.add(TodoList(imagePath: 'images/cat.png', nameList: '고양이', typeList: '포유류'));
    todoList.add(TodoList(imagePath: 'images/cow.png', nameList: '젖소', typeList: '포유류'));
    todoList.add(TodoList(imagePath: 'images/dog.png', nameList: '강아지', typeList: '포유류'));
    todoList.add(TodoList(imagePath: 'images/fox.png', nameList: '여우', typeList: '포유류'));
    todoList.add(TodoList(imagePath: 'images/monkey.png', nameList: '원숭이', typeList: '영장류'));
    todoList.add(TodoList(imagePath: 'images/pig.png', nameList: '돼지', typeList: '포유류'));
    todoList.add(TodoList(imagePath: 'images/wolf.png', nameList: '늑대', typeList: '포유류'));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Listview Text'),
      ),
      body: Center(
        child: ListView.builder(
          itemCount: todoList.length,
          itemBuilder: (context, position){
            return GestureDetector(
              child: Card(
                child: Row(
                  children: [
                    Image.asset(
                      todoList[position].imagePath,
                      height: 100,
                      width: 100,
                    ),
                    const SizedBox(
                      width: 30,
                    ),
                    Text(
                      todoList[position].nameList
                      ),
                    /*
                    Text(
                      todoList[position].typeList
                      ),
                      */
            
                  ],
                ),
              ),
              onTap: (){
                  Message.nameList = todoList[position].nameList;
                  Message.typeList= todoList[position].typeList;
                _showDialog(context);
              },
            );
          },
        ),
      ),
      
    );
  }
  _showDialog(BuildContext context)
    {
      showDialog(
        context: context, 
        builder: (BuildContext context){
        // alterdialog() == 팝업 
        return AlertDialog(
          title: Text(Message.nameList),
          content: Text('이 동물은 ${Message.typeList} 입니다.'),
          actions:[
            ElevatedButton(
              onPressed: (){
                Navigator.of(context).pop();// 팝업을 종료 후 페이지 이동 
                },
              child: const Text('종료')
            ),
          ],
        );
        }
      );
    }  


}

