import 'package:flutter/material.dart';
import 'package:tabbar_app/first_page.dart';
import 'package:tabbar_app/second_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}
// tappbar를 사용하려면 상속 받아야 된다.(with SingleTickerProviderStateMixin)
class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin {
  late TabController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // length =  화면 개수, vsync = 어디에 실행 시킬건지 
    controller = TabController(length: 2, vsync: this);
  }

  // controller 정리 후 종료 
  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tab Bar Test'),
      ),
      body: TabBarView(
        controller: controller,
        children: const[
          FirstPage(), SecondPage()
        ],
      ),
      bottomNavigationBar: TabBar(
        // 라벨 컬러 확인 
        labelColor: Colors.blue,
        //overlayColor: MaterialAccentColor.all(Color_red),
        controller: controller,
        tabs: const [
          Tab(
            icon:  Icon(
              Icons.looks_one,
              color: Colors.blue,
            ),
            text: 'one',
          ),

          Tab(
            icon:  Icon(
              Icons.looks_two,
              color: Colors.red,
            ),
            text: 'Two',
          )


        ]
      ),
    );
  }
}