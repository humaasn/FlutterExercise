import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  late List data; 

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    data=[];
    getJSONData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('JSON Test'),
      ),
      body: Container(
        child: Center(
          child: data.length ==0 
          ? const Text(
            '데이터가 없습니다.',
            style: TextStyle(
              fontSize: 20,
            ),
          )
          : ListView.builder(
            itemBuilder: (context, index){
              
              return Card(
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Text(
                          'Code : ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        //data[][내가 찾고자하는 단어]를 문자열로 바꿔줌
                        Text(data[index]['code'].toString()),
                      ],
                    ),


                     Row(
                      children: [
                        const Text(
                          'Name : ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        //data[][내가 찾고자하는 단어]를 문자열로 바꿔줌
                        Text(data[index]['Name'].toString()),
                      ],
                    ),

                     Row(
                      children: [
                        const Text(
                          'Dept : ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        //data[][내가 찾고자하는 단어]를 문자열로 바꿔줌
                        Text(data[index]['dept'].toString()),
                      ],
                    ),

                     Row(
                      children: [
                        const Text(
                          'Phone : ',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        //data[][내가 찾고자하는 단어]를 문자열로 바꿔줌
                        Text(data[index]['phone'].toString()),
                      ],
                    )


                  ],
                ),
              );
            },
            itemCount: data.length,
          ),
        ),
      ),
    );
  }
  // 이건 거의 고정이다
  Future<String> getJSONData() async{
    var url = Uri.parse('http://localhost:8080/Flutter/student.json');
    var response = await http.get(url);
    setState(() {
      var dataConvertedJSON = json.decode(response.body);
      // dataConvertedJSON[내가 찾고자하는 함수 가져오기/ table명 ];
      List result = dataConvertedJSON['results'];
      data.addAll(result);
    });
    return response.body;

  }
}

