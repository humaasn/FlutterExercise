import 'package:flutter/material.dart';

import 'package:fluttertoast/fluttertoast.dart';

class ShowPopPage extends StatefulWidget {
  const ShowPopPage({Key? key}) : super(key: key);

  @override
  _ShowPopPageState createState() => _ShowPopPageState();
}

class _ShowPopPageState extends State<ShowPopPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ShowPopPage'),
      ),
      body: Column(
        children: [
          
          TextButton(
            onPressed: () {
              showDatePickerPop();
            },
            child: Container(
              height: 50,
              margin: const EdgeInsets.all(10.0),
              padding: const EdgeInsets.only(
                left: 15,
              ),
              decoration: BoxDecoration(
                  border: Border.all(
                width: 3,
                color: Colors.amberAccent,
              )),
              alignment: Alignment.centerLeft,
              child: Text(
                'DatePicker 띄우기',
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              showTimePickerPop();
            },
            child: const Text('DatePicker'),
          ),
            
          
       
            
        ],
      ),
    );
  }

  
  /* DatePicker 띄우기 */
  void showDatePickerPop() {
    Future<DateTime?> selectedDate = showDatePicker(
      context: context,
      initialDate: DateTime.now(), //초기값
      firstDate: DateTime(2020), //시작일
      lastDate: DateTime(2022), //마지막일
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.dark(), //다크 테마
          child: child!,
        );
      },
    );

    selectedDate.then((dateTime) {
      Fluttertoast.showToast(
        msg: dateTime.toString(),
        toastLength: Toast.LENGTH_LONG,
        //gravity: ToastGravity.CENTER,  //위치(default 는 아래)
      );
    });
  }

  /* TimePicker 띄우기 */
  void showTimePickerPop() {
    Future<TimeOfDay?> selectedTime = showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    selectedTime.then((timeOfDay) {
      Fluttertoast.showToast(
        msg: timeOfDay.toString(),
        toastLength: Toast.LENGTH_LONG,
        //gravity: ToastGravity.CENTER,  //위치(default 는 아래)
      );
    });
  }
}