package com.example.simple_add_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
