import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
       
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController num1 = TextEditingController();
  TextEditingController num2 = TextEditingController();
  
  late int sum;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    sum = 0;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap:(){
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('간단한 덧셈 계산기'),
        ),
    
        body: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text('덧셈결과 $sum',
                style: const TextStyle(
                  fontSize: 25,
                ),
                ),
              ),
    
              Padding(
                //padding: const EdgeInsets.fromLTRB(20,0,20,0),
                padding: const EdgeInsets.only(left:20, right:20),
                child: SizedBox(
                  child: TextField(
                    controller: num1,
                    keyboardType: TextInputType.number,
                    //textAlign: Align(alignment: Alignment.centerRight),
                  ),
                  width: 70,
                ),
              ),
    
              Padding(
                padding: const EdgeInsets.only(left:20, right:20),
                child: SizedBox(
                  child: TextField(
                    controller: num2,
                    keyboardType: TextInputType.number,
                  ),
                  width: 70,
                ),
              ),
    
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: ElevatedButton(
                  onPressed: (){
                    setState(() {
                     sum = int.parse(num1.text) + int.parse(num2.text);
                    });
                    
                  }, 
                  child: SizedBox(
                    child: Row(
                      
                      children: const[
                        Icon(Icons.add),
                        SizedBox(
                          width: 20, 
                        ),
                        Text('덧셈 계산'),
                      ],
                    ),
                    width: 100,
                  ),
                ),
              ),
    
            ],
          ),
       ),
        
    
    
      ),
    );
  }
}
