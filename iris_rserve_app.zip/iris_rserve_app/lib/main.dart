

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}


class _MyHomePageState extends State<MyHomePage> {

  TextEditingController sepalLengthController = TextEditingController();
  TextEditingController sepalWidthController = TextEditingController();
  TextEditingController petalLengthController = TextEditingController();
  TextEditingController petalWidthController = TextEditingController();

  late String sepalLength;
  late String sepalWidth;
  late String petalLength;
  late String petalWidth;

  String result = "all";

  late String imageName;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Iris 품종예측'),
        ),
        body: Center(
          child: Column(
            children: [
    
              TextField(
                controller: sepalLengthController,
                decoration: const InputDecoration(
                  labelText: 'Sepal Length의 크기를 입력하세요',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
    
              TextField(
                controller: sepalWidthController,
                decoration: const InputDecoration(
                  labelText: 'Sepal Width의 크기를 입력하세요',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
    
              TextField(
                controller: petalLengthController,
                decoration: const InputDecoration(
                  labelText: 'Petal Length의 크기를 입력하세요',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
    
    
              TextField(
                controller: petalWidthController,
                decoration: const InputDecoration(
                  labelText: 'Petal Width의 크기를 입력하세요',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
              ),
    
              ElevatedButton(
                onPressed: (){
                  sepalLength = sepalLengthController.text.toString();
                  sepalWidth = sepalWidthController.text.toString();
                  petalLength = petalLengthController.text.toString();
                  petalWidth = sepalLengthController.text.toString();
                  getJSONDate();
                }, 
                child: const Text('입력')
              ),
    
    
              CircleAvatar(
                backgroundImage: AssetImage('images/$result.jpg'),
                radius: 100,
              )
    
            ],
          ),
        ),
        
      ),
    );
  }

  getJSONDate() async{
    var url = Uri.parse('http://localhost:8080/Flutter/request_iris.jsp?sepalLength=$sepalLength&sepalWidth=$sepalWidth&petalLength=$petalLength&petalWidth=$petalWidth');
    var response = await http.get(url);
    setState(() {
      var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
      result = dataConvertedJSON['result'];
    });
    _showDialog(context,result);
  }

  _showDialog(BuildContext context, String result){
    showDialog(
      context: context, 
      builder: (BuildContext context){
        return AlertDialog(
          title: const Text('품종 예측 결과'),
          content: Text('입력하신 품종은 $result 입니다.'),
          actions: [
            TextButton(
              onPressed: (){
                setState(() {
                  imageName = result;
                });
                Navigator.of(context).pop();
              },
              child: const Text('확인'),
            ),
          ],
        );
      }
    );
  }
}


