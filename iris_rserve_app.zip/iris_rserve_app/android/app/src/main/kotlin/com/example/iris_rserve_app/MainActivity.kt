package com.example.iris_rserve_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
