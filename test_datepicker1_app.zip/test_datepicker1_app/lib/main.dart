import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ShowPopPage'),
      ),
      body: Column(
        children: [
          
          TextButton(
            onPressed: () {
              showDatePickerPop();
            },
            child: Container(
              height: 50,
              margin: const EdgeInsets.all(10.0),
              padding: const EdgeInsets.only(
                left: 15,
              ),
              decoration: BoxDecoration(
                  border: Border.all(
                width: 3,
                color: Colors.amberAccent,
              )),
              alignment: Alignment.centerLeft,
              child: const Text(
                'DatePicker 띄우기',
              ),
            ),
          ),
         
            
          
       
            
        ],
      ),
    );
  }

  
  /* DatePicker 띄우기 */
  void showDatePickerPop() {
    Future<DateTime?> selectedDate = showDatePicker(
      context: context,
      initialDate: DateTime.now(), //초기값
      firstDate: DateTime(2020), //시작일
      lastDate: DateTime(2022), //마지막일
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.dark(), //다크 테마
          child: child!,
        );
      },
    );

    selectedDate.then((dateTime) {
      Fluttertoast.showToast(
        msg: dateTime.toString(),
        toastLength: Toast.LENGTH_LONG,
        //gravity: ToastGravity.CENTER,  //위치(default 는 아래)
      );
    });
  }

  
}


