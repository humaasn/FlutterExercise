package com.example.coffee_project_all_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
