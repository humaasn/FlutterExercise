import 'package:coffee_project_all_app/bar/bar_chart.dart';
import 'package:coffee_project_all_app/bar/bar_msg.dart';
import 'package:flutter/material.dart';
import 'dart:convert'; // for json
import 'package:http/http.dart' as http;
import 'package:charts_flutter/flutter.dart' as charts;
class BarChartView extends StatefulWidget {
  const BarChartView({ Key? key }) : super(key: key);

  @override
  _BarChartViewState createState() => _BarChartViewState();
}

class _BarChartViewState extends State<BarChartView> {
  late List<DeveloperSeries> data;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    data = [];
    getJSONData2();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bar Chart'),
        backgroundColor: Colors.black87
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.center,
            //   children: [
            //     ElevatedButton(onPressed: (){
            //       setState(() {
            //         data = [];
            //         year = 2017;
            //         getJSONData();
            //       });
            //     }, child: const Text('2017')),
            //     ElevatedButton(onPressed: (){
            //       setState(() {
            //         data = [];
            //         year = 2018;
            //         getJSONData();
            //       });
            //     }, child: const Text('2018')),
            //     ElevatedButton(onPressed: (){
            //       setState(() {
            //         data = [];
            //         year = 2019;
            //         getJSONData();
            //       });
            //     }, child: const Text('2019')),
            //   ],
            // ),
            DeveloperChart(data: data),
          ],
        ),
      ),
    );
  }

  ////////////////////////////////////////////////
  Future<String> getJSONData2() async {
    var url = Uri.parse('http://172.30.1.7:8080/Flutter/coffee_bar_flutter.jsp');
    var response = await http.get(url);
    var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
    List result = dataConvertedJSON['results'];

    setState(() {
      for (int i = 0; i < result.length; i++) {
        data.add(DeveloperSeries(
          gu: (result[i]['gu']),
          coffee: double.parse(result[i]['coffee']),
          barColor: charts.ColorUtil.fromDartColor(Colors.brown)
        ));
      }
      // data.addAll(result);
    });
    return response.body;
  }
}