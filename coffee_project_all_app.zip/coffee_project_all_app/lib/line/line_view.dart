import 'package:coffee_project_all_app/line/line_chart.dart';
import 'package:coffee_project_all_app/line/line_msg.dart';
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts; // ********
import 'dart:convert'; // for json
import 'package:http/http.dart' as http;

class LineChartView extends StatefulWidget {
  const LineChartView({ Key? key }) : super(key: key);

  @override
  _LineChartViewState createState() => _LineChartViewState();
}

class _LineChartViewState extends State<LineChartView> {
  late List<LineMSG> data;
  late List<LineMSG> data2; // <<<<<<<<<<<<<<

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    data = [];
    data2 = [];
    getJSONLineData1();
    getJSONLineData2();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Line Chart'),
        backgroundColor: Colors.black87
      ),
      body: Center(
        child: DeveloperLineChart(data: data, data2: data2),
      ),
    );
  }
  Future<String> getJSONLineData1() async {
    var url = Uri.parse('http://172.30.1.7:8080/Flutter/coffee_line_flutter.jsp');
    var response = await http.get(url);
    var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
    List result = dataConvertedJSON['results'];

    setState(() {
      for (int i = 0; i < result.length; i++) {
        data.add(LineMSG(
          year: int.parse(result[i]['year']),
          PeopleSum: double.parse(result[i]['PeopleSum']),
          barColor: charts.ColorUtil.fromDartColor(Colors.red)
        ));
      }
      // data.addAll(result);
    });
    return response.body;
  }
  ////////////////////////////////////////////////
  Future<String> getJSONLineData2() async {
    var url = Uri.parse('http://172.30.1.7:8080/Flutter/coffee_line2_flutter.jsp');
    var response = await http.get(url);
    var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
    List result = dataConvertedJSON['results'];

    setState(() {
      for (int i = 0; i < result.length; i++) {
        data2.add(LineMSG(
          year: int.parse(result[i]['year']),
          PeopleSum: double.parse(result[i]['PeopleSum']),
          barColor: charts.ColorUtil.fromDartColor(Colors.blue)
        ));
      }
      // data2.addAll(result);
    });
    return response.body;
  }

}