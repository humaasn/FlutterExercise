import 'package:charts_flutter/flutter.dart' as charts;

class  LineMSG {
  late int year;
  late double PeopleSum;
  late charts.Color barColor;
  LineMSG({
    required this.year,
    required this.PeopleSum,
    required this.barColor
  });
}