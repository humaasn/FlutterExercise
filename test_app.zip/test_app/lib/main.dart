import 'package:flutter/material.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(  
        //primarySwatch: Colors.red, // title 배경색상 변경
      ),
      home: const MyHomePage(),
    );
  }
}

class  MyHomePage extends StatelessWidget { // stl tab 누르기 
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.orange[100],
      appBar: AppBar(
        title: const Text('영웅 Card'), // myhomepage title명 지정 
        backgroundColor: Colors.orange,
      ),
      body: Padding( // 파란줄이 뜬다면 상위 폴더에 add const 클릭 (const는 안바꾸겠다는 뜻)
        padding: const EdgeInsets.fromLTRB(30.0, 0.0, 0.0, 0.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // 이순신 사진 
            const Padding(
              padding: EdgeInsets.all(30.0),
              child: Center(
                child: CircleAvatar(
                  backgroundImage: AssetImage('images/Lee.jpg'),
                  radius: 50,
                ),
              ),
            ),

            // divide 
            const Divider( // 나누기
              height: 30.0,
              color: Colors.black,
              thickness: 0.5, // 선 굵기 
            ),

          const Padding(
            padding:  EdgeInsets.all(5.0),
            child: Text(
                '영웅', 
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12.0,
                ),
            ),
          ),

           const Padding(
             padding: EdgeInsets.all(5.0),
             child: Text(
                '이순신 장군', 
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                ),
          ),
           ),

          const Padding(
            padding: EdgeInsets.all(5.0),
            child: Text(
                '전적', 
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12.0,
                ),
            ),
          ),

            const Padding(
              padding: EdgeInsets.all(5.0),
              child: Text(
                '62전 62승', 
                style: TextStyle(
                  color: Colors.orange,
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                ),
          ),
            ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '목포해전',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '사천포해전',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '당포해전',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '한산도대첩',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '부산포해전',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '명량해전',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),

          Row(
            children: const [
              Icon(Icons.check_circle_outline),
              SizedBox(
                width:10.0,
              ),
              Text(
                '노량해전',
                style: TextStyle(
                  letterSpacing: 2.0
                ),
              ),
            ],
          ),
          
          Padding(
              padding: const EdgeInsets.all(30.0),
              child: Center(
                child: Image.asset(
                  'image/turtle.gif',
                  width: 30,
                  height: 30,
                ),
              ),
            ),
          

          
          
          
          
          
          
          
          
          
          ],
        ),
      ),
    );
  }
}