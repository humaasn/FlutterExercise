import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // 입력 되어야 할 데이터 
  TextEditingController codeController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController deptController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  late String code;
  late String name; 
  late String dept; 
  late String phone; 
  // 결과 
  late String result; 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Insert & return for CRUD'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [

            TextField(
              controller: codeController,
              decoration: const InputDecoration(labelText: '학번을 입력하세요'),
              keyboardType: TextInputType.text,
            ),

            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: '이름을 입력하세요'),
              keyboardType: TextInputType.text,
            ),

            TextField(
              controller: deptController,
              decoration: const InputDecoration(labelText: '전공을 입력하세요'),
              keyboardType: TextInputType.text,
            ),

            TextField(
              controller: phoneController,
              decoration: const InputDecoration(labelText: '전화번호를 입력하세요'),
              keyboardType: TextInputType.text,
            ),

            const SizedBox(
              height: 30,
            ),

            ElevatedButton(
              onPressed: (){

                 code = codeController.text.toString();
                 name = nameController.text.toString();
                 dept = deptController.text.toString();
                 phone = phoneController.text.toString();
                 //getJSONData();
              }, 
              child: const Text('입력'),
            ),

          ],
        ),
      ),
      
    );
  }

   



}



