class Message{
  static String code = '';
  static String name = '';
  static String dept = '';
  static String phone = '';

  static String result = '';
  static bool action = true;
}