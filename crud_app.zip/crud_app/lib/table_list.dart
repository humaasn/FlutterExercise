import 'dart:convert';

import 'package:crud_app/message.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class TableList extends StatefulWidget {
  const TableList({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<TableList> {
  late List data;
  late String code;

  @override
  void initState() {
    super.initState();
    code = '';
    data = [];
    getJSONData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD Test'),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/insert')
                  .then((value) => getJSONData());
            },
            icon: const Icon(Icons.add_outlined),
          ),
        ],
      ),
      body: SizedBox(
        child: Center(
          child: data.isEmpty
              ? const Text(
                  '데이터가 없습니다.',
                  style: TextStyle(
                    fontSize: 20,
                  ),
                )
              : ListView.builder(
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      child: Card(
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const Text(
                                    'Code :',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(data[index]['code'].toString()),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const Text(
                                    'Name :',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(data[index]['name'].toString()),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const Text(
                                    'Dept :',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(data[index]['dept'].toString()),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  const Text(
                                    'Phone :',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(data[index]['phone'].toString()),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // update
                      onTap: (){

                        Message.code = data[index]['code'].toString();
                        Message.name = data[index]['name'].toString();
                        Message.dept = data[index]['dept'].toString();
                        Message.phone = data[index]['phone'].toString();

                        Navigator.pushNamed(context, '/update')
                        .then((value) => getJSONData1());

                      },

                      // delete
                      onLongPress: (){

                        Message.code = data[index]['code'].toString();
                        Message.name = data[index]['name'].toString();
                        Message.dept = data[index]['dept'].toString();
                        Message.phone = data[index]['phone'].toString();

                        //print(code);
                        Navigator.pushNamed(context, '/delete')
                        .then((value) => getJSONData1());

                      },

                    );
                  },
                  itemCount: data.length,
                ),
        ),
      ),
    );
  }

  Future<String> getJSONData() async {
    var url =
        Uri.parse('http://localhost:8080/Flutter/student_query_flutter.jsp');
    var response = await http.get(url);
    setState(() {
      // var dataConvertedJSON = json.decode(response.body);
      var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
      List result = dataConvertedJSON['results'];
      data.addAll(result);
    });
    return response.body;
  }

  Future<String> getJSONData1() async {
    var url =
        Uri.parse('http://localhost:8080/Flutter/student_select.jsp?code=$code');
    var response = await http.get(url);
    setState(() {
      // var dataConvertedJSON = json.decode(response.body);
      var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
      List result = dataConvertedJSON['results'];
      data.addAll(result);
    });
    return response.body;
  }

  // Future<String> getJSONData2() async {
  //   var url =
  //       Uri.parse('http://localhost:8080/Flutter/student_delete.jsp?code=$code');

  //   var response = await http.get(url);
  //   setState(() {
  //     // var dataConvertedJSON = json.decode(response.body);
  //     var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
  //     List result = dataConvertedJSON['results'];
  //     //data.addAll(result);
  //   });
  //   return response.body;
  // }




  //
}//END