import 'dart:convert';

import 'package:crud_app/message.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DeletePage extends StatefulWidget {
  const DeletePage({ Key? key }) : super(key: key);

  @override
  _DeletePageState createState() => _DeletePageState();
}

class _DeletePageState extends State<DeletePage> {
 TextEditingController codeController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController deptController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  late String code; //jsp 에서 입력할 때 get 방식으로 날리는 방식이랑 같음
  late String name;
  late String dept;
  late String phone;
  late String result;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    codeController.text = Message.code;
    nameController.text = Message.name;
    deptController.text = Message.dept;
    phoneController.text = Message.phone;

    }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Insert & return for CRUD'),
        ),
        body: SingleChildScrollView(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 100),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
 
                      controller: codeController,
                      decoration:
                          const InputDecoration(
                            labelText: '학번을 입력하세요.',
                            //hintText: '$code',
                            ),
                          
                      keyboardType: TextInputType.text,
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: nameController,
                      decoration:
                          const InputDecoration(labelText: '성명을 수정하세요.'),
                      keyboardType: TextInputType.text,
                    ),
                  ),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: deptController,
                      decoration:
                          const InputDecoration(labelText: '전공을 수정하세요.'),
                      keyboardType: TextInputType.text,
                    
                    ),
 
                  ),

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: phoneController,
                      decoration:
                          const InputDecoration(labelText: '전화번호을 수정하세요.'),
                      keyboardType: TextInputType.text,
                    ),
                  ),

                  const SizedBox(
                    height: 30,
                  ),

                  ElevatedButton(
                    onPressed: () {
                      code = codeController.text.toString();
                      name = nameController.text.toString();
                      dept = deptController.text.toString();
                      phone = phoneController.text.toString();
                      getJSONDate();
                    },
                    child: const Text('입력'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Future는 가져올때만 쓰는 함수
  getJSONDate() async {
    var url = Uri.parse(
        'http://localhost:8080/Flutter/student_delete.jsp?code=$code');
    var response = await http.get(url);
    setState(() {
      var dataConvertedJSON = json.decode(utf8.decode(response.bodyBytes));
      result = dataConvertedJSON['result'];
      


    });
    if(result == 'OK') {
      //good
      _showDialog(context);
    } else {
      //error
      errorSnackbar(context);
    }
  }

  _showDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('수정결과'),
          content: const Text('수정이 완료 되었습니다.'),
          actions: [
            TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('OK')),
          ],
        );
      },
    );
  } // _showDialog

  errorSnackbar(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('사용자 정보 수정에 문제가 발생하였습니다.'),
        duration: Duration(seconds: 2),
        backgroundColor: Colors.red,
      ),
    );
  } // errorSnackbar
} // <<<<