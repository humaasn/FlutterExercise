package com.example.image_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
