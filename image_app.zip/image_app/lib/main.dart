import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue, // 앱 타잍일 
      ),
      home: const MyHomePage(),
    );
  }
}
/*
class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // command 누르고 함수 선택하면 쓸수 있는게 무었인지 나온다.
    return Scaffold (

      backgroundColor: Colors.amberAccent,

      appBar: AppBar(
        title: const Text('Image Test'),
      ),
      body: Center(
        // 이미지 파일 가져오기 -> images 파일 생성 -> pubspec.yaml 클릭 해서 이미 부분 command / 누르고 images만 남게 한다.
        child: Image.asset(
          'images/smile.png',
          width: 200,
          height: 200,
        ),
      ),
    );
  }
}
*/

class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);
 // 생성자 
  @override
  Widget build(BuildContext context) {
    // command 누르고 함수 선택하면 쓸수 있는게 무엇인지 나온다.
    return Scaffold (

      backgroundColor: Colors.white,

      appBar: AppBar(
        title: const Text('Image Ex'),
      ),
      body: Center(
        // 이미지 파일 가져오기 -> images 파일 생성 -> pubspec.yaml 클릭 해서 이미 부분 command / 누르고 images만 남게 한다.
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            Image.asset(
              'images/pikachu-1.jpg',
              height: 100,
              width: 100,
            ),

            Image.asset(
              'images/pikachu-2.jpg',
              height: 100,
              width: 100,
            ),

            Image.asset(
              'images/pikachu-3.jpg',
              height: 100,
              width: 100,
            ),

          ],
        ),
      ),
    );
  }
}