package com.example.sqlite_crud_ex_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
