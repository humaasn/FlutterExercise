import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sqlite_crud_ex_app/dbhelper.dart';
import 'package:sqlite_crud_ex_app/model.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    TextEditingController idcontroller = TextEditingController();
    TextEditingController namecontroller = TextEditingController();
    TextEditingController agecontroller = TextEditingController();

    String id = "";
    String name = "";
    String age = "";

    return Scaffold(
      appBar: AppBar(
        title: const Text('sqlite example'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            TextField(
              controller: idcontroller,
              decoration: const InputDecoration(
                label: Text('ID')
              ),
              keyboardType: TextInputType.text,
            ),

            TextField(
              controller: namecontroller,
              decoration: const InputDecoration(
                label: Text('name')
              ),
              keyboardType: TextInputType.text,
            ),

            TextField(
              controller: agecontroller,
              decoration: const InputDecoration(
                label: Text('age')
              ),
              keyboardType: TextInputType.text,
            ),
            

            ElevatedButton(
              onPressed: (){
                id = idcontroller.text.toString();
                name = namecontroller.text.toString();
                age = agecontroller.text.toString() ;

                DBHelper dbHelper = DBHelper();
                dbHelper.insertDog(Dog(id: id, name: name, age: age));
                print(Dog);
              }, 
              child: const Text('INSERT')
            ),

            ElevatedButton(
              onPressed: (){
                DBHelper dbHelper = DBHelper();
                dbHelper.getAllDog().then((value) => value.forEach((element) {
                print("id: ${element.id}\nname: ${element.name}\nage: ${element.age}");
                 }));
                print(Dog);
              }, 
              child: const Text('READALL')
            ),

            ElevatedButton(
              onPressed: (){
                DBHelper dbHelper = DBHelper();
                dbHelper.getDog(12).then((value) {
                  if (value is List<Map<String, dynamic>>) {
                    value.forEach((element) {
                      element.forEach((key, value) {
                        print('$key: $value');
                      });
                    });
                  } else {
                    print('null');
                  }
                });
              }, 
              child: const Text('SELECTREAD')
            ),
            
          ],
        ),
      ),
      
    );
  }
}