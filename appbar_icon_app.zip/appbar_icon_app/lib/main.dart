import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatelessWidget {
  const MyHomePage ({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: const Text('App Bar Icon'),
        leading: IconButton(
          onPressed: (){
            print('menu button os clicked');
          }, 
          icon: const Icon(Icons.menu),
          ), // 맨 앞에서 만드는 아이콘 
        // 나머지 아이콘 만들기 
        actions: [
          IconButton(
            onPressed: (){}, 
            icon: const Icon(Icons.email),
            ),
          IconButton(
            onPressed: (){}, 
            icon: const Icon(Icons.add_alarm),
            ),
          IconButton(
            onPressed: (){}, 
            icon: const Icon(Icons.add_outlined),
          ),
          // 그림에 버튼 속성 부여
          GestureDetector(
            onTap: (){
              print('Smile image is clicked');
            },
            child: Image.asset(
              'images/smile.png',
              height: 30,
              width: 30,
            ),
          ),
        ],
      ),

    );
  }
}
