import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Buttons'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment:  MainAxisAlignment.center,
          children:  [
            TextButton(
              onPressed: (){
                print('text button'); // consol 출력 글자 
              }, 
              child: const Text(
                'Text Button',// 버튼 글자
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              style: TextButton.styleFrom( // 버튼 색깔 지정 
                primary: Colors.red, 
              ),
            ),
            // Elevated button 에서만 버튼 모서리 변경 가능 
            ElevatedButton(
              onPressed: (){
                print('Elevated button');
              }, 
              child: const Text('Elevated button'),
              style: ElevatedButton.styleFrom(
                primary: Colors.orangeAccent,
                minimumSize: const Size(200,50), // 버튼 크기 고정 
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
            ),

              OutlinedButton(
                onPressed: (){}, 
                child: const Text('Outlined button'),
                style: OutlinedButton.styleFrom(
                  primary: Colors.green,
                  // 버튼 테두리 속성 지정
                  side: const BorderSide(color: Colors.black87, width:2.0)
                ),
              ),

              TextButton.icon(
                onPressed: (){}, 
                icon: const Icon(
                  Icons.home,
                  size: 30,
                ),
                label: const Text('Go to home'),
                style: TextButton.styleFrom(
                  primary: Colors.purple,
                ),
              ),

              ElevatedButton.icon(
                onPressed: (){}, 
                icon: const Icon(
                  Icons.home,
                  size: 20,
                ), 
                label: const Text('Go to home'),
                style: ElevatedButton.styleFrom(
                  primary: Colors.black,
                ),
              ),
          ],
        ),
      ),
    );
  }
}