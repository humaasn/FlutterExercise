package com.example.mysql_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
