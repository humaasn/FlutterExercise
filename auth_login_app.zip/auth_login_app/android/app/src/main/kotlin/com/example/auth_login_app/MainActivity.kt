package com.example.auth_login_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
