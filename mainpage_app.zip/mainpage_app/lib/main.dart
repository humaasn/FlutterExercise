import 'package:flutter/material.dart';
import 'package:mainpage_app/health.dart';
import 'package:mainpage_app/heart_info.dart';
import 'package:mainpage_app/heartpre.dart';
import 'package:mainpage_app/login.dart';
import 'package:mainpage_app/userinfo.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage()
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with SingleTickerProviderStateMixin {
  late TabController controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // length =  화면 개수, vsync = 어디에 실행 시킬건지 
    controller = TabController(length: 4, vsync: this);
  }

  // controller 정리 후 종료 
  @override
  void dispose() {
    // TODO: implement dispose
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
   return Scaffold(
      appBar: AppBar(
        title: const Text('Tab Bar Test'),
      ),
      body: TabBarView(
        controller: controller,
        children: const[

          Heartinfo(), Health(), Heartpre(), Userinfo()
        ],
      ),
      bottomNavigationBar: TabBar(
          
        // 라벨 컬러 확인 
        labelColor: Colors.blue,
        //overlayColor: MaterialAccentColor.all(Color_red),
        controller: controller,
        tabs: const [
          Tab(
            icon:  Icon(
              Icons.favorite_border_outlined,
              color: Colors.red,
            ),
            text: '나의 심장',
          ),
          Tab(
            icon:  Icon(
              Icons.directions_run_outlined,
              color: Colors.blue,
            ),
            text: '운동',
          ),

          Tab(
            icon:  Icon(
              Icons.zoom_in_outlined,
              color: Colors.red,
            ),
            text: '검사',
          ),

          Tab(
            icon:  Icon(
              Icons.settings_outlined,
              color: Colors.grey,
            ),
            text: '설정',
          )


        ]
      ),
    );
  }
}
