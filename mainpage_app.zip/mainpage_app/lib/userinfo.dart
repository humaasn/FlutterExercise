import 'package:flutter/material.dart';

class Userinfo extends StatefulWidget {
  const Userinfo({ Key? key }) : super(key: key);

  @override
  _UserinfoState createState() => _UserinfoState();
}

class _UserinfoState extends State<Userinfo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    
      body: Center(
        child: Column(
          children: const [
            Text('User information')
          ],
        ),
      ),
      
    );
  }
}