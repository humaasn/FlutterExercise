import 'package:flutter/material.dart';

class Heartpre extends StatefulWidget {
  const Heartpre({ Key? key }) : super(key: key);

  @override
  _HeartpreState createState() => _HeartpreState();
}

class _HeartpreState extends State<Heartpre> {
  @override
  Widget build(BuildContext context) {
   return Scaffold(
      
      body: Center(
        child: Column(
          children: const [
            Text('Heart prediction')
          ],
        ),
      ),
    );
  }
}