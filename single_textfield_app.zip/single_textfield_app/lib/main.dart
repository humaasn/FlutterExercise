import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}
class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  
  // 글자 관리 
  TextEditingController textEditingController = TextEditingController();
  late String inputValue;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        // 다른 화면 클릭 해도 앱 스낵바 내리기 
        // GesGestureDetector 이건 scaffold with wrap 쓰기 
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Single Textfield'),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                TextField(
                  controller: textEditingController,
                  decoration: const InputDecoration(labelText: '글자를 입력하세요.'),
                  keyboardType: TextInputType.text,
                ),
                const SizedBox(
                  height: 20,
                ),
                ElevatedButton(
                  onPressed: (){
                    // text가 비어 있는지 확인하는 메소드 
                    //if(textEditingController.text == '' || textEditingController.text.isEmpty)
                  if(textEditingController.text.isNotEmpty){
                    inputValue=textEditingController.text;
                    showSnackBar(context);
                  }else{
                    errorSnackBar(context);
                  }
                }, 
                  child: const Text('출력'),
                ),
              ],
            ),
          ),
        ),
        
      ),
    );
  }
  showSnackBar(BuildContext context){
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
      content: Text('입력한 글자는 $inputValue 입니다'),
      duration: const Duration(seconds: 2),
      backgroundColor: Colors.blue,
      ),
    );
  }
  
  errorSnackBar(BuildContext context){
    ScaffoldMessenger.of(context).showSnackBar(// snackbar message 출력
      const SnackBar(
      content: Text('글자를 입력하세요'),
      duration: Duration(seconds: 2), // snackbar 출력시간
      backgroundColor: Colors.red,
      ),
    );
  }



}//end