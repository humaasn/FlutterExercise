package com.example.single_textfield_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
