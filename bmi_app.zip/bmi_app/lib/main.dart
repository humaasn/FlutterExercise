import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({ Key? key }) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController height = TextEditingController();
  TextEditingController weight = TextEditingController();
  late double bmi;
  late String result;
  late String str;
  late String str1;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    bmi = 0;
    str='';
    // 초기값 설정 
    str1='images/bmi.png';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI 계산기'),
      ),
      body: Center(
        child: Column(
          children: [
             TextField(
                    controller: height,
                    decoration:
                        const InputDecoration(labelText: '신장을 입력하세요(단위:cm'),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextField(
                    controller: weight,
                    decoration:
                        const InputDecoration(labelText: '몸무게를 입력하세요(단위:kg'),
                    keyboardType: TextInputType.number,
                  ),
                  
                  ElevatedButton(
                    onPressed: (){
                      setState(() {
                        bmi = double.parse(weight.text) * ((double.parse(height.text) * double.parse(height.text)) / 100000);
                        if(bmi >= 0 && bmi <= 18.4){
                          result = '저체중';
                          str1 = 'images/underweight.png';
                        }
                        if(bmi >= 18.5 && bmi <= 22.9){
                          result = '정상체중';
                          str1 = 'images/normal.png';
                        }
                        if(bmi >= 23 && bmi <= 24.9){
                          result = '과체중';
                          str1 = 'images/risk.png';
                        }
                        if(bmi >= 25 && bmi <= 29.9){
                          result = '비만';
                          str1 = 'images/overweight.png';
                        }
                        if(bmi >= 30){
                          result = '고도비만';
                          str1 = 'images/obese.png';
                        }

                      });

                      // 버튼 클릭 시 출력 
                      str = '귀하의 bmi지수는 $bmi이고 $result입니다.';
                      //Image.asset(image);

                    }, 
                    child: const Text('BMI 계산')),
                    

                    Padding(
                      padding: const EdgeInsets.all(40.0),
                      child: Text(str,
                        style: const TextStyle(
                          fontSize: 20.0, 
                          color: Colors.red 
                        ),
                      ),
                    ),

                    Image.asset(str1,
                    height: 300,
                    width: 300,
                    ),
          ],
        ),
      ),
    );
  }
}

